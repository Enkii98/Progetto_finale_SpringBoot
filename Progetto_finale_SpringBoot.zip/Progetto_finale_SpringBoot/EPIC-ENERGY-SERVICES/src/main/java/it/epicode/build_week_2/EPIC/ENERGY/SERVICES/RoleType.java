package it.epicode.build_week_2.EPIC.ENERGY.SERVICES;

public enum RoleType {
	ROLE_USER,
	ROLE_ADMIN
}
